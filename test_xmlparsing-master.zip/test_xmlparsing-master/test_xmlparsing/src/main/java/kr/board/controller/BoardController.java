package kr.board.controller;

import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import kr.board.entity.Board;
import kr.board.mapper.BoardMapper;


@Controller
public class BoardController {
	
	@Autowired
	private BoardMapper mapper;
	
	@Autowired
	private Board board;
	
	@RequestMapping("/")	
	public String welcome() {
		
		return "index";
		
	}
	
	@RequestMapping(value ="/updatexml")
	public String updatexml(MultipartFile xmlFile, String inputtag, String inputattr,Model model) throws Exception {
		
		
		model.addAttribute("value", "");
		
		String xmlContent = new String(xmlFile.getBytes(), StandardCharsets.UTF_8);
		
		//System.out.println(xmlContent);
		
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xmlContent)));
        

        Element systemElement = document.getDocumentElement();
        NodeList subElements = systemElement.getElementsByTagName(inputtag);
       
        if(subElements.getLength()<1) {
        	model.addAttribute("altcat","tag");
        	model.addAttribute("altmsg",inputtag);
        	return "alert";
        }
      

   
        for (int i = 0; i < subElements.getLength(); i++) {
            Element airElement = (Element) subElements.item(i);
           
            String category = airElement.getAttribute("category");
            String value = airElement.getAttribute("value");

            if (category.equals(inputattr)) {
            	
            	board.setAttr(inputattr);
            	board.setTag(inputtag);
            	board.setValue(value);
            	mapper.boardInsert(board);
            	model.addAttribute("value", value);
            	model.addAttribute("inputattr", inputattr);
            	model.addAttribute("inputtag", inputtag);
            	
                return "/index";
            }
        }
       
        	
        	model.addAttribute("altcat","attr");
        	model.addAttribute("altmsg",inputattr);
        	return "alert";
       
	}
	
	@RequestMapping(value ="/selectXml", produces = "application/json; charset=UTF-8")
	@ResponseBody()
	public List<Board> selectXml() {
		
		List<Board> blist = mapper.boardSelect();
		
		return blist;		
		
	}
	
	
	

}
