package kr.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import kr.board.entity.Board;


public interface BoardMapper {
	
	public List<Board> boardSelect(); 
	

	public void boardInsert(Board vo);

	
}
